Ausf�hren mit java -jar Uebung5.jar <ZAHL1> <ZAHL2>
R�ckgabe ist dann <ZAHL1 * ZAHL2>

Danke!
Viele Gr��e
Tobias